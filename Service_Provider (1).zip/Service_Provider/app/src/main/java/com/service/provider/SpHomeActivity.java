package com.service.provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import androidx.cardview.widget.CardView;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.ImageView;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.widget.AdapterView;
import com.bumptech.glide.Glide;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class SpHomeActivity extends  AppCompatActivity  { 
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private HashMap<String, Object> m = new HashMap<>();
	private double active_tab = 0;
	
	private ArrayList<HashMap<String, Object>> ls = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> ls2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> ls3 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> ls4 = new ArrayList<>();
	private ArrayList<String> ls_keys = new ArrayList<>();
	private ArrayList<String> ls_accepted = new ArrayList<>();
	private ArrayList<String> ls_completed = new ArrayList<>();
	
	private TabLayout tablayout2;
	private LinearLayout linear2;
	private ListView listview1_new;
	private ListView listview2_pending;
	private ListView listview3_completed;
	private ListView listview4_cancelled;
	private LinearLayout _drawer_linear1;
	private CardView _drawer_cardview1;
	private CardView _drawer_cardview2;
	private LinearLayout _drawer_linear2;
	private CircleImageView _drawer_circleimageview1;
	private TextView _drawer_textview1;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_linear3;
	private CardView _drawer_admin;
	private CardView _drawer_sp_my_ac;
	private LinearLayout _drawer_service_p;
	private CardView _drawer_add_room;
	private CardView _drawer_about;
	private LinearLayout _drawer_linear4;
	private ImageView _drawer_imageview2;
	private TextView _drawer_textview2;
	private LinearLayout _drawer_linear15;
	private ImageView _drawer_imageview9;
	private TextView _drawer_textview10;
	private CardView _drawer_availability;
	private LinearLayout _drawer_linear13;
	private ImageView _drawer_imageview7;
	private TextView _drawer_textview8;
	private LinearLayout _drawer_linear6;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview3;
	private LinearLayout _drawer_linear18;
	private ImageView _drawer_imageview12;
	private TextView _drawer_textview13;
	
	private DatabaseReference sp_wdb = _firebase.getReference("sp_works");
	private ChildEventListener _sp_wdb_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private DatabaseReference dbsp = _firebase.getReference("service_provider");
	private ChildEventListener _dbsp_child_listener;
	private Intent i = new Intent();
	private DatabaseReference db_ubook = _firebase.getReference("user_bookings");
	private ChildEventListener _db_ubook_child_listener;
	private TimerTask t;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sp_home);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(SpHomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		tablayout2 = (TabLayout) findViewById(R.id.tablayout2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		listview1_new = (ListView) findViewById(R.id.listview1_new);
		listview2_pending = (ListView) findViewById(R.id.listview2_pending);
		listview3_completed = (ListView) findViewById(R.id.listview3_completed);
		listview4_cancelled = (ListView) findViewById(R.id.listview4_cancelled);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_cardview1 = (CardView) _nav_view.findViewById(R.id.cardview1);
		_drawer_cardview2 = (CardView) _nav_view.findViewById(R.id.cardview2);
		_drawer_linear2 = (LinearLayout) _nav_view.findViewById(R.id.linear2);
		_drawer_circleimageview1 = (CircleImageView) _nav_view.findViewById(R.id.circleimageview1);
		_drawer_textview1 = (TextView) _nav_view.findViewById(R.id.textview1);
		_drawer_vscroll1 = (ScrollView) _nav_view.findViewById(R.id.vscroll1);
		_drawer_linear3 = (LinearLayout) _nav_view.findViewById(R.id.linear3);
		_drawer_admin = (CardView) _nav_view.findViewById(R.id.admin);
		_drawer_sp_my_ac = (CardView) _nav_view.findViewById(R.id.sp_my_ac);
		_drawer_service_p = (LinearLayout) _nav_view.findViewById(R.id.service_p);
		_drawer_add_room = (CardView) _nav_view.findViewById(R.id.add_room);
		_drawer_about = (CardView) _nav_view.findViewById(R.id.about);
		_drawer_linear4 = (LinearLayout) _nav_view.findViewById(R.id.linear4);
		_drawer_imageview2 = (ImageView) _nav_view.findViewById(R.id.imageview2);
		_drawer_textview2 = (TextView) _nav_view.findViewById(R.id.textview2);
		_drawer_linear15 = (LinearLayout) _nav_view.findViewById(R.id.linear15);
		_drawer_imageview9 = (ImageView) _nav_view.findViewById(R.id.imageview9);
		_drawer_textview10 = (TextView) _nav_view.findViewById(R.id.textview10);
		_drawer_availability = (CardView) _nav_view.findViewById(R.id.availability);
		_drawer_linear13 = (LinearLayout) _nav_view.findViewById(R.id.linear13);
		_drawer_imageview7 = (ImageView) _nav_view.findViewById(R.id.imageview7);
		_drawer_textview8 = (TextView) _nav_view.findViewById(R.id.textview8);
		_drawer_linear6 = (LinearLayout) _nav_view.findViewById(R.id.linear6);
		_drawer_imageview3 = (ImageView) _nav_view.findViewById(R.id.imageview3);
		_drawer_textview3 = (TextView) _nav_view.findViewById(R.id.textview3);
		_drawer_linear18 = (LinearLayout) _nav_view.findViewById(R.id.linear18);
		_drawer_imageview12 = (ImageView) _nav_view.findViewById(R.id.imageview12);
		_drawer_textview13 = (TextView) _nav_view.findViewById(R.id.textview13);
		auth = FirebaseAuth.getInstance();
		
		tablayout2.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				if (_position == 0) {
					listview1_new.setVisibility(View.VISIBLE);
					listview2_pending.setVisibility(View.GONE);
					listview3_completed.setVisibility(View.GONE);
					listview4_cancelled.setVisibility(View.GONE);
				}
				if (_position == 1) {
					listview1_new.setVisibility(View.GONE);
					listview2_pending.setVisibility(View.VISIBLE);
					listview3_completed.setVisibility(View.GONE);
					listview4_cancelled.setVisibility(View.GONE);
				}
				if (_position == 2) {
					listview1_new.setVisibility(View.GONE);
					listview2_pending.setVisibility(View.GONE);
					listview3_completed.setVisibility(View.VISIBLE);
					listview4_cancelled.setVisibility(View.GONE);
				}
				if (_position == 3) {
					listview1_new.setVisibility(View.GONE);
					listview2_pending.setVisibility(View.GONE);
					listview3_completed.setVisibility(View.GONE);
					listview4_cancelled.setVisibility(View.VISIBLE);
				}
			}
			
			@Override
			public void onTabUnselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
			
			@Override
			public void onTabReselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
		});
		
		listview2_pending.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
				return true;
			}
		});
		
		_sp_wdb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("sp_uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.get("job_status").toString().equals("pending")) {
						ls_keys.add(_childKey);
						ls.add(_childValue);
						listview1_new.setAdapter(new Listview1_newAdapter(ls));
						((BaseAdapter)listview1_new.getAdapter()).notifyDataSetChanged();
					}
					if (_childValue.get("job_status").toString().equals("accepted")) {
						ls_accepted.add(_childKey);
						ls2.add(_childValue);
						listview2_pending.setAdapter(new Listview2_pendingAdapter(ls2));
						((BaseAdapter)listview2_pending.getAdapter()).notifyDataSetChanged();
					}
					if (_childValue.get("job_status").toString().equals("completed")) {
						ls_completed.add(_childKey);
						ls3.add(_childValue);
						listview3_completed.setAdapter(new Listview3_completedAdapter(ls3));
						((BaseAdapter)listview3_completed.getAdapter()).notifyDataSetChanged();
					}
					if (_childValue.get("job_status").toString().equals("rejected")) {
						ls4.add(_childValue);
						listview4_cancelled.setAdapter(new Listview4_cancelledAdapter(ls4));
						((BaseAdapter)listview4_cancelled.getAdapter()).notifyDataSetChanged();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("sp_uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.get("job_status").toString().equals("pending")) {
						ls_keys.add(_childKey);
						ls.add(_childValue);
						listview1_new.setAdapter(new Listview1_newAdapter(ls));
						((BaseAdapter)listview1_new.getAdapter()).notifyDataSetChanged();
					}
					if (_childValue.get("job_status").toString().equals("accepted")) {
						ls_accepted.add(_childKey);
						ls2.add(_childValue);
						listview2_pending.setAdapter(new Listview2_pendingAdapter(ls2));
						((BaseAdapter)listview2_pending.getAdapter()).notifyDataSetChanged();
					}
					if (_childValue.get("job_status").toString().equals("completed")) {
						ls_completed.add(_childKey);
						ls3.add(_childValue);
						listview3_completed.setAdapter(new Listview3_completedAdapter(ls3));
						((BaseAdapter)listview3_completed.getAdapter()).notifyDataSetChanged();
					}
					if (_childValue.get("job_status").toString().equals("rejected")) {
						ls4.add(_childValue);
						listview4_cancelled.setAdapter(new Listview4_cancelledAdapter(ls4));
						((BaseAdapter)listview4_cancelled.getAdapter()).notifyDataSetChanged();
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sp_wdb.addChildEventListener(_sp_wdb_child_listener);
		
		_dbsp_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childValue.get("uid").toString())) {
					_drawer_textview1.setText(_childValue.get("name").toString());
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("profile_pic").toString())).into(_drawer_circleimageview1);
					if (_childValue.get("isAdmin").toString().equals("true")) {
						_drawer_admin.setVisibility(View.VISIBLE);
					}
					else {
						_drawer_admin.setVisibility(View.GONE);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dbsp.addChildEventListener(_dbsp_child_listener);
		
		_db_ubook_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_ubook.addChildEventListener(_db_ubook_child_listener);
		
		_drawer_admin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setClass(getApplicationContext(), AdminActivity.class);
				i.putExtra("title", "About Us");
				startActivity(i);
			}
		});
		
		_drawer_sp_my_ac.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setClass(getApplicationContext(), ProfileActivity.class);
				startActivity(i);
			}
		});
		
		_drawer_add_room.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setClass(getApplicationContext(), HomeRentalActivity.class);
				startActivity(i);
			}
		});
		
		_drawer_about.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setClass(getApplicationContext(), AboutActivity.class);
				i.putExtra("title", "About Us");
				i.putExtra("edit", "false");
				startActivity(i);
			}
		});
		
		_drawer_availability.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setAction(Intent.ACTION_VIEW);
				i.setClass(getApplicationContext(), AvailabilityActivity.class);
				startActivity(i);
			}
		});
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Service Provider");
		tablayout2.addTab(tablayout2.newTab().setText("New Request"));
		tablayout2.addTab(tablayout2.newTab().setText("pending works"));
		tablayout2.addTab(tablayout2.newTab().setText("completed works"));
		tablayout2.addTab(tablayout2.newTab().setText("cancelled works"));
		_drawer_imageview2.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview9.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview7.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview12.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		_drawer_imageview3.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		_drawer_cardview2.setCardBackgroundColor(0xFFFF9310);
		_drawer_cardview2.setPreventCornerOverlap(true);
		listview1_new.setVisibility(View.VISIBLE);
		listview2_pending.setVisibility(View.GONE);
		listview3_completed.setVisibility(View.GONE);
		listview4_cancelled.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	public void _prog (final boolean _ifShow, final String _t, final String _m) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setTitle(_t);
			prog.setMessage(_m);
			prog.show();
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	public class Listview1_newAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview1_newAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.work_list, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView pp = (ImageView) _view.findViewById(R.id.pp);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final LinearLayout linear_btn = (LinearLayout) _view.findViewById(R.id.linear_btn);
			final TextView name = (TextView) _view.findViewById(R.id.name);
			final TextView job_desc = (TextView) _view.findViewById(R.id.job_desc);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView location = (TextView) _view.findViewById(R.id.location);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView time = (TextView) _view.findViewById(R.id.time);
			final Button button1_accept = (Button) _view.findViewById(R.id.button1_accept);
			final Button button2_reject = (Button) _view.findViewById(R.id.button2_reject);
			
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("c_pic").toString())).into(pp);
			name.setText(_data.get((int)_position).get("c_name").toString());
			job_desc.setText(_data.get((int)_position).get("c_jobdesc").toString());
			location.setText(_data.get((int)_position).get("c_address").toString());
			time.setText(_data.get((int)_position).get("time").toString());
			if (_data.get((int)_position).get("job_status").toString().equals("pending")) {
				linear_btn.setVisibility(View.VISIBLE);
			}
			else {
				linear_btn.setVisibility(View.GONE);
			}
			button1_accept.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_prog(true, "Accepting work", "please wait...");
					m = new HashMap<>();
					m.put("job_status", "accepted");
					sp_wdb.child(ls_keys.get((int)(_position))).updateChildren(m);
					db_ubook.child(ls_keys.get((int)(_position))).updateChildren(m);
					ls.remove((int)(_position));
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									_prog(false, "", "");
								}
							});
						}
					};
					_timer.schedule(t, (int)(5000));
				}
			});
			button2_reject.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_prog(true, "Rejecting work", "please wait...");
					m = new HashMap<>();
					m.put("job_status", "rejected");
					sp_wdb.child(ls_keys.get((int)(_position))).updateChildren(m);
					db_ubook.child(ls_keys.get((int)(_position))).updateChildren(m);
					ls.remove((int)(_position));
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									_prog(false, "", "");
								}
							});
						}
					};
					_timer.schedule(t, (int)(5000));
				}
			});
			
			return _view;
		}
	}
	
	public class Listview2_pendingAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview2_pendingAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.work_list, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView pp = (ImageView) _view.findViewById(R.id.pp);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final LinearLayout linear_btn = (LinearLayout) _view.findViewById(R.id.linear_btn);
			final TextView name = (TextView) _view.findViewById(R.id.name);
			final TextView job_desc = (TextView) _view.findViewById(R.id.job_desc);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView location = (TextView) _view.findViewById(R.id.location);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView time = (TextView) _view.findViewById(R.id.time);
			final Button button1_accept = (Button) _view.findViewById(R.id.button1_accept);
			final Button button2_reject = (Button) _view.findViewById(R.id.button2_reject);
			
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("c_pic").toString())).into(pp);
			name.setText(_data.get((int)_position).get("c_name").toString());
			job_desc.setText(_data.get((int)_position).get("c_jobdesc").toString());
			location.setText(_data.get((int)_position).get("c_address").toString());
			time.setText(_data.get((int)_position).get("time").toString());
			linear_btn.setVisibility(View.GONE);
			cardview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setAction(Intent.ACTION_VIEW);
					i.putExtra("s_key", ls_accepted.get((int)(_position)));
					i.putExtra("sp_uid", _data.get((int)_position).get("sp_uid").toString());
					i.setClass(getApplicationContext(), SpWorkCheckoutActivity.class);
					startActivity(i);
				}
			});
			
			return _view;
		}
	}
	
	public class Listview3_completedAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview3_completedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.work_list, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView pp = (ImageView) _view.findViewById(R.id.pp);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final LinearLayout linear_btn = (LinearLayout) _view.findViewById(R.id.linear_btn);
			final TextView name = (TextView) _view.findViewById(R.id.name);
			final TextView job_desc = (TextView) _view.findViewById(R.id.job_desc);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView location = (TextView) _view.findViewById(R.id.location);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView time = (TextView) _view.findViewById(R.id.time);
			final Button button1_accept = (Button) _view.findViewById(R.id.button1_accept);
			final Button button2_reject = (Button) _view.findViewById(R.id.button2_reject);
			
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("c_pic").toString())).into(pp);
			name.setText(_data.get((int)_position).get("c_name").toString());
			job_desc.setText(_data.get((int)_position).get("c_jobdesc").toString());
			location.setText(_data.get((int)_position).get("c_address").toString());
			time.setText(_data.get((int)_position).get("time").toString());
			linear_btn.setVisibility(View.GONE);
			cardview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setAction(Intent.ACTION_VIEW);
					i.putExtra("s_key", ls_completed.get((int)(_position)));
					i.putExtra("sp_uid", _data.get((int)_position).get("sp_uid").toString());
					i.setClass(getApplicationContext(), SpWorkCheckoutActivity.class);
					startActivity(i);
				}
			});
			
			return _view;
		}
	}
	
	public class Listview4_cancelledAdapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview4_cancelledAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.work_list, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView pp = (ImageView) _view.findViewById(R.id.pp);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final LinearLayout linear_btn = (LinearLayout) _view.findViewById(R.id.linear_btn);
			final TextView name = (TextView) _view.findViewById(R.id.name);
			final TextView job_desc = (TextView) _view.findViewById(R.id.job_desc);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView location = (TextView) _view.findViewById(R.id.location);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView time = (TextView) _view.findViewById(R.id.time);
			final Button button1_accept = (Button) _view.findViewById(R.id.button1_accept);
			final Button button2_reject = (Button) _view.findViewById(R.id.button2_reject);
			
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("c_pic").toString())).into(pp);
			name.setText(_data.get((int)_position).get("c_name").toString());
			job_desc.setText(_data.get((int)_position).get("c_jobdesc").toString());
			location.setText(_data.get((int)_position).get("c_address").toString());
			time.setText(_data.get((int)_position).get("time").toString());
			linear_btn.setVisibility(View.GONE);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}