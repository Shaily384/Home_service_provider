package com.service.provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.material.button.*;
import android.widget.EditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import java.util.concurrent.TimeUnit;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class LoginActivity extends  AppCompatActivity  { 
	
	
	private String verification_id = "";
	private String mob_no = "";
	private boolean signup = false;
	private boolean isNewUser = false;
	private HashMap<String, Object> map = new HashMap<>();
	private boolean isProfileExist = false;
	
	private ScrollView vscroll2;
	private LinearLayout linear2;
	private LinearLayout linear22;
	private CardView login;
	private CardView verify;
	private ImageView back;
	private TextView textview6;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private MaterialButton materialbutton2;
	private CardView cardview8;
	private CardView cardview9;
	private LinearLayout linear16;
	private ImageView imageview7;
	private TextView textview9;
	private LinearLayout linear17;
	private EditText mobno;
	private LinearLayout linear18;
	private CardView cardview12;
	private LinearLayout linear20;
	private MaterialButton materialbutton6;
	private LinearLayout linear21;
	private EditText otp;
	private TextView textview11;
	private TextView textview12;
	
	private FirebaseAuth auth;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private PhoneAuthProvider.OnVerificationStateChangedCallbacks fauth;
	private PhoneAuthProvider.ForceResendingToken fauth_resendToken;
	private SharedPreferences sp;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear22 = (LinearLayout) findViewById(R.id.linear22);
		login = (CardView) findViewById(R.id.login);
		verify = (CardView) findViewById(R.id.verify);
		back = (ImageView) findViewById(R.id.back);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		materialbutton2 = (MaterialButton) findViewById(R.id.materialbutton2);
		cardview8 = (CardView) findViewById(R.id.cardview8);
		cardview9 = (CardView) findViewById(R.id.cardview9);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview9 = (TextView) findViewById(R.id.textview9);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		mobno = (EditText) findViewById(R.id.mobno);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		cardview12 = (CardView) findViewById(R.id.cardview12);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		materialbutton6 = (MaterialButton) findViewById(R.id.materialbutton6);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		otp = (EditText) findViewById(R.id.otp);
		textview11 = (TextView) findViewById(R.id.textview11);
		textview12 = (TextView) findViewById(R.id.textview12);
		auth = FirebaseAuth.getInstance();
		sp = getSharedPreferences("data", Activity.MODE_PRIVATE);
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				login.setVisibility(View.VISIBLE);
				verify.setVisibility(View.GONE);
				back.setVisibility(View.GONE);
			}
		});
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mobno.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "enter phone no");
				}
				else {
					sp.edit().putString("mobno", "+91".concat(mobno.getText().toString())).commit();
					PhoneAuthProvider.getInstance().verifyPhoneNumber("+91".concat(mobno.getText().toString()), 60, TimeUnit.SECONDS, LoginActivity.this, fauth);
				}
			}
		});
		
		materialbutton6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FirebaseAuth.getInstance().signInWithCredential(PhoneAuthProvider.getCredential(verification_id, otp.getText().toString())).addOnCompleteListener(auth_phoneAuthListener);
			}
		});
		
		textview12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				PhoneAuthProvider.getInstance().verifyPhoneNumber(sp.getString("mobno", ""), 60, TimeUnit.SECONDS, LoginActivity.this, fauth, fauth_resendToken);
			}
		});
		
		fauth = new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
			@Override
			public void onVerificationCompleted(PhoneAuthCredential _credential) {
				FirebaseAuth.getInstance().signInWithCredential(_credential).addOnCompleteListener(auth_phoneAuthListener);
				SketchwareUtil.showMessage(getApplicationContext(), "phone number verified");
			}
			
			@Override
			public void onVerificationFailed(FirebaseException e) {
				final String _exception = e.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _exception);
			}
			
			@Override
			public void onCodeSent(String _verificationId, PhoneAuthProvider.ForceResendingToken _token) {
				verification_id = _verificationId;
				fauth_resendToken = _token;
				SketchwareUtil.showMessage(getApplicationContext(), "code sent successfully");
				login.setVisibility(View.GONE);
				verify.setVisibility(View.VISIBLE);
				back.setVisibility(View.VISIBLE);
				textview6.setText("Verify to continue");
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				if (_success) {
					SketchwareUtil.showMessage(getApplicationContext(), "sign in complete");
					isNewUser = task.getResult().getAdditionalUserInfo().isNewUser();
					if (isNewUser) {
						sp.edit().putString("isNewUser", "true").commit();
						i.setAction(Intent.ACTION_VIEW);
						i.setClass(getApplicationContext(), CreateprofileActivity.class);
						i.putExtra("be_sp", "false");
						startActivity(i);
						finish();
					}
					else {
						sp.edit().putString("isNewUser", "false").commit();
						i.setAction(Intent.ACTION_VIEW);
						i.setClass(getApplicationContext(), MainActivity.class);
						startActivity(i);
						finish();
					}
				}
				else {
					if (_errorMessage.equals("The sms verification code used to create the phone auth credential is invalid. Please resend the verification code sms and be sure use the verification code provided by the user.")) {
						SketchwareUtil.showMessage(getApplicationContext(), "Invalid verification code");
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
					}
				}
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		login.setVisibility(View.VISIBLE);
		verify.setVisibility(View.GONE);
		back.setVisibility(View.GONE);
		imageview7.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}