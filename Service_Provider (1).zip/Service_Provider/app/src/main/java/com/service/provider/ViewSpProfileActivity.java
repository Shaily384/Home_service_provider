package com.service.provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import com.google.android.material.button.*;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class ViewSpProfileActivity extends  AppCompatActivity  { 
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> m = new HashMap<>();
	private String key = "";
	private String sp_uid = "";
	private String user_uid = "";
	private String key2 = "";
	private String mobno = "";
	private String c_pp = "";
	private String c_name = "";
	private String c_location = "";
	private String c_lat = "";
	private String c_long = "";
	private String city = "";
	private String state = "";
	private String sp_pp = "";
	private String sp_mn = "";
	private String sp_name = "";
	private String sp_loc = "";
	private String sp_charges = "";
	private String sp_cate = "";
	private String sp_desc = "";
	private String sp_email = "";
	private String sp_upiid = "";
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private CardView cardview1;
	private LinearLayout linear10;
	private LinearLayout linear3;
	private LinearLayout linear7;
	private LinearLayout linear5;
	private LinearLayout linear8;
	private MaterialButton button_hire;
	private LinearLayout linear2;
	private CircleImageView circleimageview1;
	private TextView name;
	private LinearLayout sp;
	private LinearLayout linear6;
	private TextView description;
	private ImageView img_category;
	private TextView category;
	private ImageView imageview7;
	private TextView charges;
	private ImageView imageview1;
	private TextView pn;
	private ImageView imageview4;
	private TextView email;
	private ImageView imageview2;
	private TextView location;
	private ImageView imageview5;
	private TextView address;
	
	private Intent i = new Intent();
	private DatabaseReference db_ub = _firebase.getReference("user_bookings");
	private ChildEventListener _db_ub_child_listener;
	private DatabaseReference sp_workdb = _firebase.getReference("sp_works");
	private ChildEventListener _sp_workdb_child_listener;
	private FirebaseAuth fauth;
	private OnCompleteListener<Void> fauth_updateEmailListener;
	private OnCompleteListener<Void> fauth_updatePasswordListener;
	private OnCompleteListener<Void> fauth_emailVerificationSentListener;
	private OnCompleteListener<Void> fauth_deleteUserListener;
	private OnCompleteListener<Void> fauth_updateProfileListener;
	private OnCompleteListener<AuthResult> fauth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fauth_googleSignInListener;
	private OnCompleteListener<AuthResult> _fauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fauth_sign_in_listener;
	private OnCompleteListener<Void> _fauth_reset_password_listener;
	private DatabaseReference db_users = _firebase.getReference("users");
	private ChildEventListener _db_users_child_listener;
	private AlertDialog.Builder d;
	private Calendar calendar = Calendar.getInstance();
	private TimerTask t;
	private DatabaseReference dbsp = _firebase.getReference("service_provider");
	private ChildEventListener _dbsp_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view_sp_profile);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		cardview1 = (CardView) findViewById(R.id.cardview1);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		button_hire = (MaterialButton) findViewById(R.id.button_hire);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		name = (TextView) findViewById(R.id.name);
		sp = (LinearLayout) findViewById(R.id.sp);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		description = (TextView) findViewById(R.id.description);
		img_category = (ImageView) findViewById(R.id.img_category);
		category = (TextView) findViewById(R.id.category);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		charges = (TextView) findViewById(R.id.charges);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		pn = (TextView) findViewById(R.id.pn);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		email = (TextView) findViewById(R.id.email);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		location = (TextView) findViewById(R.id.location);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		address = (TextView) findViewById(R.id.address);
		fauth = FirebaseAuth.getInstance();
		d = new AlertDialog.Builder(this);
		
		button_hire.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				key = db_ub.push().getKey();
				m = new HashMap<>();
				m.put("c_uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				m.put("c_address", c_location);
				m.put("c_pic", c_pp);
				m.put("c_name", c_name);
				m.put("c_phone", mobno);
				m.put("c_latitude", c_lat);
				m.put("c_longitude", c_long);
				m.put("c_city", city);
				m.put("c_state", state);
				m.put("c_jobdesc", "job description...");
				m.put("sp_uid", sp_uid);
				m.put("sp_address", sp_loc);
				m.put("sp_pic", sp_pp);
				m.put("sp_name", sp_name);
				m.put("sp_phone", sp_mn);
				m.put("sp_latitude", c_lat);
				m.put("sp_longitude", c_long);
				m.put("sp_jobdesc", sp_desc);
				m.put("sp_charges", sp_charges);
				m.put("sp_category", sp_cate);
				m.put("sp_email", sp_email);
				m.put("job_status", "pending");
				m.put("time", new SimpleDateFormat("dd-MM-yyyy  hh:mm a").format(calendar.getTime()));
				m.put("pay_status", "false");
				m.put("total_charges", "0");
				m.put("child_key", key);
				m.put("sp_upiid", sp_upiid);
				sp_workdb.child(key).updateChildren(m);
				db_ub.child(key).updateChildren(m);
				_prog(true, "Please wait", "Sending request...");
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_prog(false, "", "");
								d.setTitle("Request sent successfully...");
								d.setMessage("Service provider contact you soon...\nyou can check status of work in manage booking section.\n\nThank you!");
								d.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
									@Override
									public void onClick(DialogInterface _dialog, int _which) {
										i.setAction(Intent.ACTION_VIEW);
										i.setClass(getApplicationContext(), ManagebookingActivity.class);
										startActivity(i);
									}
								});
								d.setCancelable(false);
								d.create().show();
							}
						});
					}
				};
				_timer.schedule(t, (int)(5000));
			}
		});
		
		_db_ub_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_ub.addChildEventListener(_db_ub_child_listener);
		
		_sp_workdb_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sp_workdb.addChildEventListener(_sp_workdb_child_listener);
		
		_db_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.containsKey("uid")) {
					if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childValue.get("uid").toString())) {
						c_pp = _childValue.get("profile_pic").toString();
						mobno = _childValue.get("mob_no").toString();
						c_name = _childValue.get("name").toString();
						c_location = _childValue.get("location").toString();
						c_lat = _childValue.get("latitude").toString();
						c_long = _childValue.get("longitude").toString();
						city = _childValue.get("city").toString();
						state = _childValue.get("state").toString();
					}
				}
				/*
sp_upiid = _childValue.get("upi_id").toString();
*/
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_users.addChildEventListener(_db_users_child_listener);
		
		_dbsp_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dbsp.addChildEventListener(_dbsp_child_listener);
		
		fauth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fauth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("View Profile");
		sp_pp = getIntent().getStringExtra("profile_pic");
		sp_mn = getIntent().getStringExtra("mob_no");
		sp_name = getIntent().getStringExtra("name");
		sp_loc = getIntent().getStringExtra("location");
		sp_cate = getIntent().getStringExtra("category");
		sp_desc = getIntent().getStringExtra("description");
		sp_email = getIntent().getStringExtra("email");
		sp_charges = getIntent().getStringExtra("charges");
		sp_uid = getIntent().getStringExtra("uid");
		user_uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
		sp_upiid = getIntent().getStringExtra("upi_id");
		name.setText(getIntent().getStringExtra("name"));
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("profile_pic"))).into(circleimageview1);
		category.setText(getIntent().getStringExtra("category"));
		pn.setText(getIntent().getStringExtra("mob_no"));
		description.setText(getIntent().getStringExtra("description"));
		location.setText(getIntent().getStringExtra("location"));
		email.setText(getIntent().getStringExtra("email"));
		address.setText(getIntent().getStringExtra("address"));
		Glide.with(getApplicationContext()).load(Uri.parse(getIntent().getStringExtra("category_image"))).into(img_category);
		charges.setText(getIntent().getStringExtra("charges"));
		if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(sp_uid)) {
			button_hire.setEnabled(false);
		}
		else {
			button_hire.setEnabled(true);
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _prog (final boolean _ifShow, final String _t, final String _m) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setTitle(_t);
			prog.setMessage(_m);
			prog.show();
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}