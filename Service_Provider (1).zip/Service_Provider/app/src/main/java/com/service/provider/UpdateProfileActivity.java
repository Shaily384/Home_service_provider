package com.service.provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import com.google.android.material.button.*;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.content.Intent;
import android.content.ClipData;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.OnProgressListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Continuation;
import android.net.Uri;
import java.io.File;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import android.view.View;
import com.bumptech.glide.Glide;
import java.text.DecimalFormat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;


public class UpdateProfileActivity extends  AppCompatActivity  { 
	
	public final int REQ_CD_FP = 101;
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private boolean isSp = false;
	private HashMap<String, Object> m = new HashMap<>();
	private String img_path = "";
	private String img_name = "";
	private HashMap<String, Object> data = new HashMap<>();
	private boolean isAdmin = false;
	private String strCity = "";
	private String strAdd = "";
	private String strCountry = "";
	private String strState = "";
	private String strPC = "";
	private String strKN = "";
	private String paymode2 = "";
	private String pay_mode = "";
	private String lat = "";
	private String lon = "";
	
	private ArrayList<String> ls = new ArrayList<>();
	
	private ScrollView vscroll2;
	private LinearLayout linear2;
	private CardView signUp;
	private LinearLayout linear;
	private CardView cardview5;
	private CardView cardview1;
	private LinearLayout linear3;
	private CardView cardview3;
	private LinearLayout sprovider;
	private MaterialButton materialbutton2;
	private ImageView imageview4;
	private LinearLayout linear4;
	private ImageView imageview1;
	private EditText name;
	private CardView cardview2;
	private CardView cardview4;
	private LinearLayout linear5;
	private ImageView imageview2;
	private TextView textview1;
	private LinearLayout linear6;
	private EditText mobno;
	private LinearLayout linear7;
	private ImageView imageview3;
	private EditText location;
	private ImageView get_location;
	private LinearLayout categorySpinner;
	private TextView textview3;
	private TextView textview_category;
	private CardView cardview7;
	private CardView cardview9;
	private CardView cardview8;
	private LinearLayout linear10;
	private TextView textview2;
	private Spinner spinner1;
	private EditText desc;
	private LinearLayout linear9;
	private ImageView imageview5;
	private EditText sp_email;
	private EditText address;
	private CardView cardview14;
	private TextView textview4;
	private LinearLayout linear15;
	private CardView cardview13;
	private LinearLayout linear16;
	private ImageView imageview9;
	private EditText charges;
	private TextView textview5;
	private CheckBox checkbox_pmode1;
	private CheckBox checkbox_pmode2;
	private LinearLayout linear14;
	private ImageView imageview8;
	private EditText upi_id;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private DatabaseReference db_user = _firebase.getReference("users");
	private ChildEventListener _db_user_child_listener;
	private DatabaseReference db_sp = _firebase.getReference("service_provider");
	private ChildEventListener _db_sp_child_listener;
	private StorageReference fs = _firebase_storage.getReference("profile_pic");
	private OnCompleteListener<Uri> _fs_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fs_download_success_listener;
	private OnSuccessListener _fs_delete_success_listener;
	private OnProgressListener _fs_upload_progress_listener;
	private OnProgressListener _fs_download_progress_listener;
	private OnFailureListener _fs_failure_listener;
	private LocationManager getLocation;
	private LocationListener _getLocation_location_listener;
	private DatabaseReference db_category = _firebase.getReference("category");
	private ChildEventListener _db_category_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.update_profile);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		signUp = (CardView) findViewById(R.id.signUp);
		linear = (LinearLayout) findViewById(R.id.linear);
		cardview5 = (CardView) findViewById(R.id.cardview5);
		cardview1 = (CardView) findViewById(R.id.cardview1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		cardview3 = (CardView) findViewById(R.id.cardview3);
		sprovider = (LinearLayout) findViewById(R.id.sprovider);
		materialbutton2 = (MaterialButton) findViewById(R.id.materialbutton2);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		name = (EditText) findViewById(R.id.name);
		cardview2 = (CardView) findViewById(R.id.cardview2);
		cardview4 = (CardView) findViewById(R.id.cardview4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		mobno = (EditText) findViewById(R.id.mobno);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		location = (EditText) findViewById(R.id.location);
		get_location = (ImageView) findViewById(R.id.get_location);
		categorySpinner = (LinearLayout) findViewById(R.id.categorySpinner);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview_category = (TextView) findViewById(R.id.textview_category);
		cardview7 = (CardView) findViewById(R.id.cardview7);
		cardview9 = (CardView) findViewById(R.id.cardview9);
		cardview8 = (CardView) findViewById(R.id.cardview8);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		textview2 = (TextView) findViewById(R.id.textview2);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		desc = (EditText) findViewById(R.id.desc);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		sp_email = (EditText) findViewById(R.id.sp_email);
		address = (EditText) findViewById(R.id.address);
		cardview14 = (CardView) findViewById(R.id.cardview14);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		cardview13 = (CardView) findViewById(R.id.cardview13);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		charges = (EditText) findViewById(R.id.charges);
		textview5 = (TextView) findViewById(R.id.textview5);
		checkbox_pmode1 = (CheckBox) findViewById(R.id.checkbox_pmode1);
		checkbox_pmode2 = (CheckBox) findViewById(R.id.checkbox_pmode2);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		upi_id = (EditText) findViewById(R.id.upi_id);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		getLocation = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		auth = FirebaseAuth.getInstance();
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (img_path.equals("")) {
					if (name.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "please enter name");
					}
					else {
						if (location.getText().toString().equals("")) {
							SketchwareUtil.showMessage(getApplicationContext(), "please wait... getting location");
							getLocation.removeUpdates(_getLocation_location_listener);
							if (ContextCompat.checkSelfPermission(UpdateProfileActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
								getLocation.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, _getLocation_location_listener);
							}
						}
						else {
							if (location.getText().toString().equals("No Address Found")) {
								SketchwareUtil.showMessage(getApplicationContext(), "please wait... getting location");
								getLocation.removeUpdates(_getLocation_location_listener);
								if (ContextCompat.checkSelfPermission(UpdateProfileActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
									getLocation.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, _getLocation_location_listener);
								}
							}
							else {
								if (isSp) {
									if (sp_email.getText().toString().equals("")) {
										SketchwareUtil.showMessage(getApplicationContext(), "please enter email address");
									}
									else {
										if (address.getText().toString().equals("")) {
											SketchwareUtil.showMessage(getApplicationContext(), "please enter address");
										}
										else {
											if (charges.getText().toString().equals("")) {
												SketchwareUtil.showMessage(getApplicationContext(), "please enter service charges");
											}
											else {
												if (!(checkbox_pmode1.isChecked() || checkbox_pmode2.isChecked())) {
													SketchwareUtil.showMessage(getApplicationContext(), "Please select atleast one payment mode");
												}
												else {
													if (upi_id.getText().toString().equals("")) {
														SketchwareUtil.showMessage(getApplicationContext(), "please enter valid upi id");
													}
													else {
														if (checkbox_pmode1.isChecked()) {
																pay_mode = checkbox_pmode1.getText().toString();
														}
														else {
																pay_mode = "";
														}
														if (checkbox_pmode2.isChecked()) {
																paymode2 = checkbox_pmode2.getText().toString()+", ";
														}
														else {
																paymode2 = "";
														}
														data = new HashMap<>();
														data.put("name", name.getText().toString());
														data.put("location", location.getText().toString());
														data.put("latitude", lat);
														data.put("longitude", lon);
														data.put("city", strCity);
														data.put("state", strState);
														data.put("description", desc.getText().toString());
														data.put("email", sp_email.getText().toString());
														data.put("address", address.getText().toString());
														data.put("charges", charges.getText().toString());
														data.put("upi_id", upi_id.getText().toString());
														data.put("pay_mode", paymode2.concat(pay_mode));
														db_sp.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(data);
														db_user.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(data);
													}
												}
											}
										}
									}
								}
								else {
									data = new HashMap<>();
									data.put("name", name.getText().toString());
									data.put("location", location.getText().toString());
									data.put("latitude", lat);
									data.put("longitude", lon);
									data.put("city", strCity);
									data.put("state", strState);
									db_user.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(data);
								}
							}
						}
					}
				}
				else {
					if (name.getText().toString().equals("")) {
						SketchwareUtil.showMessage(getApplicationContext(), "please enter name");
					}
					else {
						if (location.getText().toString().equals("")) {
							SketchwareUtil.showMessage(getApplicationContext(), "please wait... getting location");
							getLocation.removeUpdates(_getLocation_location_listener);
							if (ContextCompat.checkSelfPermission(UpdateProfileActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
								getLocation.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, _getLocation_location_listener);
							}
						}
						else {
							if (location.getText().toString().equals("No Address Found")) {
								SketchwareUtil.showMessage(getApplicationContext(), "please wait... getting location");
								getLocation.removeUpdates(_getLocation_location_listener);
								if (ContextCompat.checkSelfPermission(UpdateProfileActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
									getLocation.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, _getLocation_location_listener);
								}
							}
							else {
								if (isSp) {
									if (sp_email.getText().toString().equals("")) {
										SketchwareUtil.showMessage(getApplicationContext(), "please enter email address");
									}
									else {
										if (address.getText().toString().equals("")) {
											SketchwareUtil.showMessage(getApplicationContext(), "please enter address");
										}
										else {
											if (charges.getText().toString().equals("")) {
												SketchwareUtil.showMessage(getApplicationContext(), "please enter service charges");
											}
											else {
												if (!(checkbox_pmode1.isChecked() || checkbox_pmode2.isChecked())) {
													SketchwareUtil.showMessage(getApplicationContext(), "Please select atleast one payment mode");
												}
												else {
													if (upi_id.getText().toString().equals("")) {
														SketchwareUtil.showMessage(getApplicationContext(), "please enter valid upi id");
													}
													else {
														if (checkbox_pmode1.isChecked()) {
																pay_mode = checkbox_pmode1.getText().toString();
														}
														else {
																pay_mode = "";
														}
														if (checkbox_pmode2.isChecked()) {
																paymode2 = checkbox_pmode2.getText().toString()+", ";
														}
														else {
																paymode2 = "";
														}
														fs.child(img_name).putFile(Uri.fromFile(new File(img_path))).addOnFailureListener(_fs_failure_listener).addOnProgressListener(_fs_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
															@Override
															public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
																return fs.child(img_name).getDownloadUrl();
															}}).addOnCompleteListener(_fs_upload_success_listener);
													}
												}
											}
										}
									}
								}
								else {
									fs.child(img_name).putFile(Uri.fromFile(new File(img_path))).addOnFailureListener(_fs_failure_listener).addOnProgressListener(_fs_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
										@Override
										public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
											return fs.child(img_name).getDownloadUrl();
										}}).addOnCompleteListener(_fs_upload_success_listener);
								}
							}
						}
					}
				}
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		get_location.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				getLocation.removeUpdates(_getLocation_location_listener);
				if (ContextCompat.checkSelfPermission(UpdateProfileActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
					getLocation.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, _getLocation_location_listener);
				}
			}
		});
		
		_db_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childValue.get("uid").toString())) {
					if (_childValue.get("isServiceP").toString().equals("true")) {
						isSp = true;
						sprovider.setVisibility(View.VISIBLE);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("profile_pic").toString())).into(imageview4);
						mobno.setText(_childValue.get("mob_no").toString());
						name.setText(_childValue.get("name").toString());
						location.setText(_childValue.get("location").toString());
						textview_category.setText(_childValue.get("category").toString());
						desc.setText(_childValue.get("description").toString());
						sp_email.setText(_childValue.get("email").toString());
						address.setText(_childValue.get("address").toString());
						charges.setText(_childValue.get("charges").toString());
						upi_id.setText(_childValue.get("upi_id").toString());
						if (_childValue.get("pay_mode").toString().contains("UPI (online)")) {
							checkbox_pmode1.setChecked(true);
						}
						else {
							checkbox_pmode1.setChecked(false);
						}
						if (_childValue.get("pay_mode").toString().contains("CASH")) {
							checkbox_pmode2.setChecked(true);
						}
						else {
							checkbox_pmode2.setChecked(false);
						}
					}
					else {
						isSp = false;
						sprovider.setVisibility(View.GONE);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("profile_pic").toString())).into(imageview4);
						mobno.setText(_childValue.get("mob_no").toString());
						name.setText(_childValue.get("name").toString());
						location.setText(_childValue.get("location").toString());
					}
					if (_childValue.get("isAdmin").toString().equals("true")) {
						isAdmin = true;
					}
					else {
						isAdmin = false;
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				SketchwareUtil.showMessage(getApplicationContext(), "profile updated successfully");
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_user.addChildEventListener(_db_user_child_listener);
		
		_db_sp_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				SketchwareUtil.showMessage(getApplicationContext(), "profile updated successfully");
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_sp.addChildEventListener(_db_sp_child_listener);
		
		_fs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(_progressValue)));
			}
		};
		
		_fs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fs_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				data = new HashMap<>();
				data.put("name", name.getText().toString());
				data.put("location", location.getText().toString());
				data.put("profile_pic", _downloadUrl);
				data.put("city", strCity);
				data.put("state", strState);
				data.put("latitude", lat);
				data.put("longitude", lon);
				if (isSp) {
					data.put("description", desc.getText().toString());
					data.put("email", sp_email.getText().toString());
					data.put("address", address.getText().toString());
					data.put("charges", charges.getText().toString());
					data.put("upi_id", upi_id.getText().toString());
					data.put("pay_mode", paymode2.concat(pay_mode));
					db_sp.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(data);
				}
				else {
					
				}
				db_user.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(data);
			}
		};
		
		_fs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fs_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fs_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_getLocation_location_listener = new LocationListener() {
			@Override
			public void onLocationChanged(Location _param1) {
				final double _lat = _param1.getLatitude();
				final double _lng = _param1.getLongitude();
				final double _acc = _param1.getAccuracy();
				_getLocation(_lat, _lng);
				location.setText(strAdd);
				lat = String.valueOf(_lat);
				lon = String.valueOf(_lng);
			}
			@Override
			public void onStatusChanged(String provider, int status, Bundle extras) {}
			@Override
			public void onProviderEnabled(String provider) {}
			@Override
			public void onProviderDisabled(String provider) {}
		};
		
		_db_category_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_category.addChildEventListener(_db_category_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if (ContextCompat.checkSelfPermission(UpdateProfileActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
			getLocation.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 50, _getLocation_location_listener);
		}
		imageview1.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		imageview2.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		imageview3.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		get_location.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		imageview5.setColorFilter(0xFFFF9310, PorterDuff.Mode.MULTIPLY);
		sprovider.setVisibility(View.GONE);
		categorySpinner.setVisibility(View.GONE);
		isSp = false;
		setTitle("Update Profile");
		location.setEnabled(false);
		mobno.setEnabled(false);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				imageview4.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_filePath.get((int)(0)), 1024, 1024));
				img_path = _filePath.get((int)(0));
				img_name = Uri.parse(_filePath.get((int)(0))).getLastPathSegment();
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public void _getLocation (final double _LATITUDE, final double _LONGITUDE) {
		android.location.Geocoder geocoder = new android.location.Geocoder(getApplicationContext(), Locale.getDefault());
		
		try {
			List<android.location.Address> addresses = geocoder.getFromLocation(_LATITUDE, _LONGITUDE, 1);
			if (addresses != null) {
				android.location.Address returnedAddress = addresses.get(0);
				StringBuilder strReturnedAddress = new StringBuilder("");
				StringBuilder strReturnedCity = new StringBuilder("");
				StringBuilder strReturnedState = new StringBuilder("");
				StringBuilder strReturnedCountry = new StringBuilder("");
				StringBuilder strReturnedPC = new StringBuilder("");
				StringBuilder strReturnedKN = new StringBuilder("");
				for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
					strReturnedAddress.append(returnedAddress.getAddressLine(i));
					strReturnedCity.append(returnedAddress.getLocality()); 
					strReturnedState.append(returnedAddress.getAdminArea());
					strReturnedCountry.append(returnedAddress.getCountryName());
					strReturnedPC.append(returnedAddress.getPostalCode());
					strReturnedKN.append(returnedAddress.getFeatureName());
				}
				strAdd = strReturnedAddress.toString();
				strCity = strReturnedCity.toString();
				strState = strReturnedState.toString();
				strCountry = strReturnedCountry.toString();
				strPC = strReturnedPC.toString();
				strKN = strReturnedKN.toString();
			}
			else
			{
				strAdd = "No Address Found";
				strCity = "No City Found";
				strState = "No State returned";
				strCountry = "No Country Found";
				strPC = "No Postal Code Found";
				strKN = "No Know Name Found";
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			strAdd = "Can't get Address";
			strCity = "Can't get City";
			strState = "Can't get State";
			strCountry = "Can't get Country";
			strPC = "Can't get Postal Code";
			strKN = "Can't get Name";
		}
	}
	
	
	public class Spinner1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Spinner1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.spinner_category, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}