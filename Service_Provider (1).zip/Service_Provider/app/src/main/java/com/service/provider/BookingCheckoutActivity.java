package com.service.provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import androidx.cardview.widget.CardView;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.Button;
import com.google.android.material.button.*;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;


public class BookingCheckoutActivity extends  AppCompatActivity  { 
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String sp_uid = "";
	private HashMap<String, Object> m = new HashMap<>();
	private String sp_phone = "";
	private String upi_id = "";
	private String charges = "";
	private String name_ = "";
	private double amount = 0;
	
	private CardView cardview1;
	private TextView textview2;
	private TextView textview_status;
	private TextView textview3;
	private TextView textview4;
	private LinearLayout linear9;
	private LinearLayout linear_pay;
	private LinearLayout linear1;
	private ImageView pp;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear6;
	private LinearLayout linear8;
	private TextView name;
	private TextView category;
	private LinearLayout linear7;
	private ImageView imageview1;
	private TextView location;
	private TextView description;
	private Button button1;
	private LinearLayout linear10;
	private Button button2;
	private TextView textview1;
	private LinearLayout linear12;
	private TextView amount_to_pay;
	private MaterialButton materialbutton1;
	
	private DatabaseReference u_b_db = _firebase.getReference("user_bookings");
	private ChildEventListener _u_b_db_child_listener;
	private Intent ii = new Intent();
	private Intent pay = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.booking_checkout);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CALL_PHONE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		cardview1 = (CardView) findViewById(R.id.cardview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview_status = (TextView) findViewById(R.id.textview_status);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear_pay = (LinearLayout) findViewById(R.id.linear_pay);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		pp = (ImageView) findViewById(R.id.pp);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		name = (TextView) findViewById(R.id.name);
		category = (TextView) findViewById(R.id.category);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		location = (TextView) findViewById(R.id.location);
		description = (TextView) findViewById(R.id.description);
		button1 = (Button) findViewById(R.id.button1);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		button2 = (Button) findViewById(R.id.button2);
		textview1 = (TextView) findViewById(R.id.textview1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		amount_to_pay = (TextView) findViewById(R.id.amount_to_pay);
		materialbutton1 = (MaterialButton) findViewById(R.id.materialbutton1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (sp_phone.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "please wait...");
				}
				else {
					ii.setAction(Intent.ACTION_CALL);
					ii.setData(Uri.parse("tel:"+sp_phone));
					startActivity(ii);
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				amount = Double.parseDouble(charges);
				pay.setData(Uri.parse("upi://pay?pa="+upi_id+"&pn="+name_+"&tn=Paying for Services&am="+amount+"&cu=INR"));
				pay.setAction(Intent.ACTION_VIEW);
				Intent chooser = Intent.createChooser(pay, "Choose App to Make Payment");
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN){
					 startActivityForResult(chooser, 2, null);
				}
			}
		});
		
		_u_b_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (sp_uid.equals(_childValue.get("sp_uid").toString())) {
					name_ = _childValue.get("sp_name").toString();
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sp_pic").toString())).into(pp);
					name.setText(_childValue.get("sp_name").toString());
					category.setText(_childValue.get("sp_category").toString());
					location.setText(_childValue.get("sp_address").toString());
					description.setText(_childValue.get("sp_jobdesc").toString());
					textview_status.setText(_childValue.get("job_status").toString());
					textview4.setText(_childValue.get("time").toString());
					sp_phone = _childValue.get("sp_phone").toString();
					if (_childValue.get("job_status").toString().equals("pending")) {
						button1.setEnabled(false);
						button2.setEnabled(false);
					}
					else {
						button1.setEnabled(true);
						button2.setEnabled(true);
					}
					if (_childValue.containsKey("pay_status")) {
						if (_childValue.get("pay_status").toString().equals("true")) {
							linear_pay.setVisibility(View.VISIBLE);
							if (_childValue.containsKey("sp_upiid")) {
								upi_id = _childValue.get("sp_upiid").toString();
							}
							if (_childValue.containsKey("total_charges")) {
								charges = _childValue.get("total_charges").toString();
							}
						}
						else {
							linear_pay.setVisibility(View.GONE);
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (sp_uid.equals(_childValue.get("sp_uid").toString())) {
					name_ = _childValue.get("sp_name").toString();
					Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sp_pic").toString())).into(pp);
					name.setText(_childValue.get("sp_name").toString());
					category.setText(_childValue.get("sp_category").toString());
					location.setText(_childValue.get("sp_address").toString());
					description.setText(_childValue.get("sp_jobdesc").toString());
					textview_status.setText(_childValue.get("job_status").toString());
					textview4.setText(_childValue.get("time").toString());
					sp_phone = _childValue.get("sp_phone").toString();
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		u_b_db.addChildEventListener(_u_b_db_child_listener);
	}
	
	private void initializeLogic() {
		setTitle("Checkout");
		sp_uid = getIntent().getStringExtra("sp_uid");
		linear_pay.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}