package com.service.provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import android.widget.EditText;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;


public class SpWorkCheckoutActivity extends  AppCompatActivity  { 
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String key = "";
	private HashMap<String, Object> m = new HashMap<>();
	private String sp_uid = "";
	private String lat = "";
	private String lon = "";
	private String phoneno = "";
	private String c_uid = "";
	
	private LinearLayout linear1;
	private LinearLayout linear7;
	private LinearLayout linear2;
	private LinearLayout linear_d1;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private TextView textview2;
	private TextView s_cate;
	private TextView textview3;
	private TextView s_date;
	private TextView textview5;
	private TextView s_status;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private Button button5_jobcompleted;
	private TextView textview7;
	private LinearLayout linear15;
	private ImageView imageview3;
	private TextView name;
	private TextView textview11;
	private TextView desc;
	private TextView textview9;
	private LinearLayout address;
	private TextView textview_addr;
	private ImageView imageview2;
	private Button button1_call;
	private LinearLayout linear13;
	private Button button2_message;
	private LinearLayout linear16;
	private CardView cardview1;
	private Button button3_send_money;
	private TextView textview13;
	private EditText edittext_amount;
	
	private DatabaseReference db_spw = _firebase.getReference("sp_works");
	private ChildEventListener _db_spw_child_listener;
	private DatabaseReference db_ubook = _firebase.getReference("user_bookings");
	private ChildEventListener _db_ubook_child_listener;
	private FirebaseAuth fauth;
	private OnCompleteListener<Void> fauth_updateEmailListener;
	private OnCompleteListener<Void> fauth_updatePasswordListener;
	private OnCompleteListener<Void> fauth_emailVerificationSentListener;
	private OnCompleteListener<Void> fauth_deleteUserListener;
	private OnCompleteListener<Void> fauth_updateProfileListener;
	private OnCompleteListener<AuthResult> fauth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fauth_googleSignInListener;
	private OnCompleteListener<AuthResult> _fauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fauth_sign_in_listener;
	private OnCompleteListener<Void> _fauth_reset_password_listener;
	private TimerTask t;
	private Intent ii = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sp_work_checkout);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CALL_PHONE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear_d1 = (LinearLayout) findViewById(R.id.linear_d1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		textview2 = (TextView) findViewById(R.id.textview2);
		s_cate = (TextView) findViewById(R.id.s_cate);
		textview3 = (TextView) findViewById(R.id.textview3);
		s_date = (TextView) findViewById(R.id.s_date);
		textview5 = (TextView) findViewById(R.id.textview5);
		s_status = (TextView) findViewById(R.id.s_status);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		button5_jobcompleted = (Button) findViewById(R.id.button5_jobcompleted);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		name = (TextView) findViewById(R.id.name);
		textview11 = (TextView) findViewById(R.id.textview11);
		desc = (TextView) findViewById(R.id.desc);
		textview9 = (TextView) findViewById(R.id.textview9);
		address = (LinearLayout) findViewById(R.id.address);
		textview_addr = (TextView) findViewById(R.id.textview_addr);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		button1_call = (Button) findViewById(R.id.button1_call);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		button2_message = (Button) findViewById(R.id.button2_message);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		cardview1 = (CardView) findViewById(R.id.cardview1);
		button3_send_money = (Button) findViewById(R.id.button3_send_money);
		textview13 = (TextView) findViewById(R.id.textview13);
		edittext_amount = (EditText) findViewById(R.id.edittext_amount);
		fauth = FirebaseAuth.getInstance();
		
		button5_jobcompleted.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_prog(true, "Sending request", "please wait");
				m = new HashMap<>();
				m.put("job_status", "completed");
				db_spw.child(key).updateChildren(m);
				db_ubook.child(key).updateChildren(m);
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_prog(false, "", "");
							}
						});
					}
				};
				_timer.schedule(t, (int)(3000));
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Uri uri=Uri.parse("geo:"+lat+","+lon);
				
				Intent map=new Intent(Intent.ACTION_VIEW,uri);
				map.setPackage("com.google.android.apps.maps");
				startActivity(map);
			}
		});
		
		button1_call.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (phoneno.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "please wait...");
				}
				else {
					ii.setAction(Intent.ACTION_CALL);
					ii.setData(Uri.parse("tel:"+phoneno));
					startActivity(ii);
				}
			}
		});
		
		button2_message.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		button3_send_money.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext_amount.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "please enter amount");
				}
				else {
					_prog(true, "Sending request", "please wait");
					m = new HashMap<>();
					m.put("pay_status", "true");
					m.put("total_charges", edittext_amount.getText().toString());
					db_spw.child(key).updateChildren(m);
					db_ubook.child(key).updateChildren(m);
					t = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									_prog(false, "", "");
								}
							});
						}
					};
					_timer.schedule(t, (int)(3000));
				}
			}
		});
		
		_db_spw_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (sp_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.get("child_key").toString().equals(key)) {
						name.setText(_childValue.get("c_name").toString());
						s_cate.setText(_childValue.get("sp_category").toString());
						s_date.setText(_childValue.get("time").toString());
						s_status.setText(_childValue.get("job_status").toString());
						desc.setText(_childValue.get("c_jobdesc").toString());
						textview_addr.setText(_childValue.get("c_address").toString());
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("c_pic").toString())).into(imageview3);
						lat = _childValue.get("c_latitude").toString();
						lon = _childValue.get("c_longitude").toString();
						phoneno = _childValue.get("c_phone").toString();
						if (_childValue.get("job_status").toString().equals("completed")) {
							linear14.setVisibility(View.GONE);
							button5_jobcompleted.setVisibility(View.GONE);
						}
						else {
							linear14.setVisibility(View.VISIBLE);
							button5_jobcompleted.setVisibility(View.VISIBLE);
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (sp_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.get("child_key").toString().equals(key)) {
						name.setText(_childValue.get("c_name").toString());
						s_cate.setText(_childValue.get("sp_category").toString());
						s_date.setText(_childValue.get("time").toString());
						s_status.setText(_childValue.get("job_status").toString());
						desc.setText(_childValue.get("c_jobdesc").toString());
						textview_addr.setText(_childValue.get("c_address").toString());
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("c_pic").toString())).into(imageview3);
						lat = _childValue.get("c_latitude").toString();
						lon = _childValue.get("c_longitude").toString();
						phoneno = _childValue.get("c_phone").toString();
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_spw.addChildEventListener(_db_spw_child_listener);
		
		_db_ubook_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db_ubook.addChildEventListener(_db_ubook_child_listener);
		
		fauth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fauth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fauth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task){
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		key = getIntent().getStringExtra("s_key");
		sp_uid = getIntent().getStringExtra("sp_uid");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _prog (final boolean _ifShow, final String _t, final String _m) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setTitle(_t);
			prog.setMessage(_m);
			prog.show();
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}